<?php echo $__env->make('includes.ecomm_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-header border-bottom mb-8">
    <div class="container">
        <div class="d-md-flex justify-content-between align-items-center py-4">
            <h1 class="page-title font-size-3 font-weight-medium m-0 text-lh-lg">Shop</h1>
            <nav class="woocommerce-breadcrumb font-size-2">
                
                <a href="<?php echo e(URL::to('QuranStore')); ?>" class="h-primary">Shop</a>
                <?php echo $__env->yieldContent('tag'); ?>
            </nav>
        </div>
    </div>
</div>

<?php echo $__env->yieldContent('ecomm_content'); ?>

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\MyWork\laravel_prg\KanzulImaan\resources\views/layouts/ecomm.blade.php ENDPATH**/ ?>
<?php echo e($slot); ?>

<?php /**PATH D:\MyWork\laravel_prg\KanzulImaan\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('ecomm_content'); ?>
    <div class="site-content" id="content">
        <div class="container">
            <div class="row">
                <div id="primary" class="content-area order-2">
                    <div
                        class="shop-control-bar d-lg-flex justify-content-between align-items-center mb-5 text-center text-md-left">
                        
                        <div class="shop-control-bar__right d-md-flex align-items-center">
                            
                            <ul class="nav nav-tab ml-lg-4 justify-content-center justify-content-md-start ml-md-auto"
                                id="pills-tab" role="tablist">
                                <li class="nav-item border">
                                    <a class="nav-link p-0 height-38 width-38 justify-content-center d-flex align-items-center active"
                                        id="pills-one-example1-tab" data-toggle="pill" href="#pills-one-example1"
                                        role="tab" aria-controls="pills-one-example1" aria-selected="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                            width="17px" height="17px">
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M-0.000,0.000 L3.000,0.000 L3.000,3.000 L-0.000,3.000 L-0.000,0.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M7.000,0.000 L10.000,0.000 L10.000,3.000 L7.000,3.000 L7.000,0.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M14.000,0.000 L17.000,0.000 L17.000,3.000 L14.000,3.000 L14.000,0.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M-0.000,7.000 L3.000,7.000 L3.000,10.000 L-0.000,10.000 L-0.000,7.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M7.000,7.000 L10.000,7.000 L10.000,10.000 L7.000,10.000 L7.000,7.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M14.000,7.000 L17.000,7.000 L17.000,10.000 L14.000,10.000 L14.000,7.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M-0.000,14.000 L3.000,14.000 L3.000,17.000 L-0.000,17.000 L-0.000,14.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M7.000,14.000 L10.000,14.000 L10.000,17.000 L7.000,17.000 L7.000,14.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M14.000,14.000 L17.000,14.000 L17.000,17.000 L14.000,17.000 L14.000,14.000 Z" />
                                        </svg>
                                    </a>
                                </li>
                                <li class="nav-item border">
                                    <a class="nav-link p-0 height-38 width-38 justify-content-center d-flex align-items-center"
                                        id="pills-two-example1-tab" data-toggle="pill" href="#pills-two-example1"
                                        role="tab" aria-controls="pills-two-example1" aria-selected="false">
                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                            width="23px" height="17px">
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M-0.000,0.000 L3.000,0.000 L3.000,3.000 L-0.000,3.000 L-0.000,0.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M7.000,0.000 L23.000,0.000 L23.000,3.000 L7.000,3.000 L7.000,0.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M-0.000,7.000 L3.000,7.000 L3.000,10.000 L-0.000,10.000 L-0.000,7.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M7.000,7.000 L23.000,7.000 L23.000,10.000 L7.000,10.000 L7.000,7.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M-0.000,14.000 L3.000,14.000 L3.000,17.000 L-0.000,17.000 L-0.000,14.000 Z" />
                                            <path fill-rule="evenodd" fill="rgb(25, 17, 11)"
                                                d="M7.000,14.000 L23.000,14.000 L23.000,17.000 L7.000,17.000 L7.000,14.000 Z" />
                                        </svg>
                                    </a>
                                </li>
                            </ul>

                            
                        </div>
                    </div>

                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-one-example1" role="tabpanel"
                            aria-labelledby="pills-one-example1-tab">

                            <ul
                                class="products list-unstyled row no-gutters row-cols-2 row-cols-lg-4 border-top border-left mb-6">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="product col">
                                        <div class="product__inner overflow-hidden p-3 p-md-4d875">
                                            <div
                                                class="woocommerce-LoopProduct-link woocommerce-loop-product__link d-block position-relative">
                                                <div class="woocommerce-loop-product__thumbnail">
                                                    <a href="<?php echo e(URL::to('Product/id=' . Crypt::encrypt($product->id))); ?>"
                                                        class="d-block">
                                                        <?php if(isset($pimage[$product->id])): ?>
                                                            <img src="<?php echo e(asset('back/images/product_images/' . $pimage[$product->id])); ?>"
                                                                class="img-fluid d-block mx-auto attachment-shop_catalog size-shop_catalog wp-post-image img-fluid"
                                                                alt="image-description">
                                                        <?php endif; ?>
                                                    </a>
                                                </div>
                                                <div class="woocommerce-loop-product__body product__body pt-3 bg-white">
                                                    <div class="text-uppercase font-size-1 mb-1 text-truncate"><a
                                                            href="<?php echo e(URL::to('Product/id=' . Crypt::encrypt($product->id))); ?>"><?php echo e($product->format); ?></a>
                                                    </div>
                                                    <h2
                                                        class="woocommerce-loop-product__title product__title h6 text-lh-md mb-1 text-height-2 crop-text-2 h-dark">
                                                        <a
                                                            href="<?php echo e(URL::to('Product/id=' . Crypt::encrypt($product->id))); ?>"><?php echo e(Str::of($product->description)->words(4, '.....')); ?></a>
                                                    </h2>
                                                    
                                                    <div
                                                        class="price d-flex align-items-center font-weight-medium font-size-3">
                                                        <span class="woocommerce-Price-amount amount"><span
                                                                class="woocommerce-Price-currencySymbol">₹</span><?php echo e($product->price); ?></span>
                                                    </div>
                                                </div>
                                                <div class="product__hover d-flex align-items-center">
                                                    <form class="addToCart">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" class="pid" name="pid"
                                                            value="<?php echo e($product->id); ?>">
                                                        <input type="hidden" class="user_id" name="user_id"
                                                            value="<?php echo e(Auth::user()->id); ?>">
                                                        <input type="hidden" class="quantity" name="quantity"
                                                            value="1">
                                                    </form>
                                                    <a href="#"
                                                        class="text-uppercase text-dark h-dark font-weight-medium mr-auto addTocartbut"
                                                        data-toggle="tooltip" data-placement="right" title=""
                                                        data-original-title="Buy Now">
                                                        <span class="product__add-to-cart">Buy Now</span>
                                                        <span class="product__add-to-cart-icon font-size-4"><i
                                                                class="flaticon-icon-126515"></i></span>
                                                    </a>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                        </div>
                        <div class="tab-pane fade" id="pills-two-example1" role="tabpanel"
                            aria-labelledby="pills-two-example1-tab">

                            <ul class="products list-unstyled mb-6">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="product product__lst">
                                        <div class="product__inner overflow-hidden p-3 p-md-4d875">
                                            <div
                                                class="woocommerce-LoopProduct-link woocommerce-loop-product__link row position-relative">
                                                <div class="col-md-auto woocommerce-loop-product__thumbnail mb-3 mb-md-0">
                                                    <a href="<?php echo e(URL::to('Product/id=' . Crypt::encrypt($product->id))); ?>"
                                                        class="d-block">
                                                        <?php if(isset($pimage[$product->id])): ?>
                                                            <img src="<?php echo e(asset('back/images/product_images/' . $pimage[$product->id])); ?>"
                                                                class="img-fluid d-block mx-auto attachment-shop_catalog size-shop_catalog wp-post-image img-fluid"
                                                                alt="image-description">
                                                        <?php endif; ?>
                                                    </a>
                                                </div>
                                                <div
                                                    class="col-md woocommerce-loop-product__body product__body pt-3 bg-white mb-3 mb-md-0">
                                                    <div class="text-uppercase font-size-1 mb-1 text-truncate"><a
                                                            href="<?php echo e(URL::to('Product/id=' . Crypt::encrypt($product->id))); ?>"><?php echo e($product->format); ?></a>
                                                    </div>
                                                    <h2
                                                        class="woocommerce-loop-product__title product__title h6 text-lh-md mb-1 crop-text-2 h-dark">
                                                        <a href="<?php echo e(URL::to('Product/id=' . Crypt::encrypt($product->id))); ?>"
                                                            tabindex="0"><?php echo e(Str::of($product->description)->words(4, '.....')); ?></a>
                                                    </h2>
                                                    
                                                    <p class="font-size-2 mb-2 crop-text-2">
                                                        <?php echo e(Str::of($product->description)->words(15, '.....')); ?></p>
                                                    <div
                                                        class="price d-flex align-items-center font-weight-medium font-size-3">
                                                        <span class="woocommerce-Price-amount amount"><span
                                                                class="woocommerce-Price-currencySymbol">₹</span><?php echo e($product->price); ?></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-auto d-flex align-items-center">
                                                    <a href="<?php echo e(URL::to('Product/id=' . Crypt::encrypt($product->id))); ?>"
                                                        class="text-uppercase text-dark h-dark font-weight-medium mr-4"
                                                        data-toggle="tooltip" data-placement="right" title=""
                                                        data-original-title="ADD TO CART">
                                                        <span class="product__add-to-cart">ADD TO CART</span>
                                                        <span class="product__add-to-cart-icon font-size-4"><i
                                                                class="flaticon-icon-126515"></i></span>
                                                    </a>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                        </div>
                    </div>

                    
                </div>
                <div id="secondary" class="sidebar widget-area order-1" role="complementary">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(".addTocartbut").click(function(e) {
            var pid = $(this).closest(".product__hover").find(".pid").val();
            var uid = $(this).closest(".product__hover").find(".user_id").val();
            var quan = $(this).closest(".product__hover").find(".quantity").val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('AddCart')); ?>",
                data: {
                    "pid": pid,
                    "user_id": uid,
                    "quantity": quan,
                },
                success: function(response) {
                    if (response.type == 'success') {
                        Swal.fire({
                            title: response.type,
                            text: response.message,
                            icon: response.type,
                            confirmButtonText: 'Done'
                        });
                        self.location = "<?php echo e(URL::to('Checkout')); ?>";
                    } else if (response.type == 'error') {
                        Swal.fire({
                            title: response.type,
                            text: response.message,
                            icon: response.type,
                            confirmButtonText: 'Done'
                        });
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ecomm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\laravel_prg\KanzulImaan\resources\views/pages/ecomm/shop.blade.php ENDPATH**/ ?>
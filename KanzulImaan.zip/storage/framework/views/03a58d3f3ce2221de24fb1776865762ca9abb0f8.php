<?php $__env->startSection('ecomm_content'); ?>
<?php $__env->startSection('class'); ?>
    class="right-sidebar woocommerce-checkout"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tag'); ?>
    <span class="breadcrumb-separator mx-1"><i class="fas fa-angle-right"></i></span>CheckOut
<?php $__env->stopSection(); ?>
<div id="content" class="site-content bg-punch-light space-bottom-3">
    <div class="col-full container">
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <article id="post-6" class="post-6 page type-page status-publish hentry">
                    <header class="entry-header space-top-2 space-bottom-1 mb-2">
                        <h4 class="entry-title font-size-7 text-center">Checkout</h4>
                    </header>

                    <div class="entry-content">
                        <div class="woocommerce">
                            
                            <form name="checkout" method="post" id="placeOrder"
                                class="checkout woocommerce-checkout row mt-8" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="col2-set col-md-6 col-lg-7 col-xl-8 mb-6 mb-md-0" id="customer_details">
                                    <div class="px-4 pt-5 bg-white border">
                                        <div class="woocommerce-billing-fields">
                                            <h3 class="mb-4 font-size-3">Billing details</h3>
                                            <div class="woocommerce-billing-fields__field-wrapper row">
                                                <p class="col-lg-6 mb-4d75 form-row form-row-first validate-required woocommerce-invalid woocommerce-invalid-required-field"
                                                    id="billing_first_name_field" data-priority="10">
                                                    <label for="billing_first_name" class="form-label">First name <abbr
                                                            class="required" title="required">*</abbr></label>
                                                    <input type="text" class="input-text form-control"
                                                        name="billing_first_name" id="billing_first_name" value=""
                                                        autocomplete="given-name" required autofocus="autofocus">
                                                </p>
                                                <p class="col-lg-6 mb-4d75 form-row form-row-last validate-required"
                                                    id="billing_last_name_field" data-priority="20">
                                                    <label for="billing_last_name" class="form-label">Last name <abbr
                                                            class="required" title="required">*</abbr></label>
                                                    <input type="text" class="input-text form-control"
                                                        name="billing_last_name" id="billing_last_name" placeholder=""
                                                        value="" autocomplete="family-name" required>
                                                </p>
                                                <p class="col-lg-6 mb-4d75 form-row form-row-first validate-required validate-phone"
                                                    id="billing_phone_field" data-priority="100">
                                                    <label for="billing_phone" class="form-label">Phone <abbr
                                                            class="required" title="required">*</abbr></label>
                                                    <input type="tel" class="input-text form-control"
                                                        name="billing_phone" id="billing_phone" placeholder=""
                                                        value="" autocomplete="tel" required>
                                                </p>
                                                <p class="col-lg-6 mb-4d75 form-row form-row-last validate-required validate-email"
                                                    id="billing_email_field" data-priority="110">
                                                    <label for="billing_email" class="form-label">Email address <abbr
                                                            class="required" title="required">*</abbr></label>
                                                    <input type="email" class="input-text form-control"
                                                        name="billing_email" id="billing_email" placeholder=""
                                                        value="" autocomplete="email" required>
                                                </p>
                                                
                                                <p class="col-12 mb-3 form-row form-row-wide address-field validate-required"
                                                    id="billing_address_1_field" data-priority="50">
                                                    <label for="billing_address_1" class="form-label">Street address
                                                        <abbr class="required" title="required">*</abbr></label>
                                                    <input type="text" class="input-text form-control"
                                                        name="billing_address_1" id="billing_address_1"
                                                        placeholder="House number and street name" value=""
                                                        autocomplete="address-line1" required>
                                                </p>
                                                <p class="col-12 mb-4d75 form-row form-row-wide address-field"
                                                    id="billing_address_2_field" data-priority="60">
                                                    <input type="text" class="input-text form-control"
                                                        name="billing_address_2" id="billing_address_2"
                                                        placeholder="Apartment, suite, unit etc. (optional)"
                                                        value="" autocomplete="address-line2">
                                                </p>
                                                <p class="col-lg-6 mb-4d75 form-row form-row-wide address-field validate-required"
                                                    id="billing_city_field" data-priority="70"
                                                    data-o_class="form-row form-row-wide address-field validate-required">
                                                    <label for="billing_city" class="form-label">Town / City <abbr
                                                            class="required" title="required">*</abbr></label>
                                                    <input type="text" class="input-text form-control"
                                                        name="billing_city" id="billing_city" value=""
                                                        autocomplete="address-level2" required>
                                                </p>
                                                
                                                <p class="col-lg-6 mb-4d75 form-row form-row-wide address-field validate-postcode validate-required"
                                                    id="billing_postcode_field" data-priority="90"
                                                    data-o_class="form-row form-row-wide address-field validate-required validate-postcode">
                                                    <label for="billing_postcode" class="form-label">Postcode <abbr
                                                            class="required" title="required">*</abbr></label>
                                                    <input type="text" class="input-text form-control"
                                                        name="billing_postcode" id="billing_postcode" placeholder=""
                                                        value="" autocomplete="postal-code" required>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <h3 id="order_review_heading" class="d-none">Your order</h3>
                                <div id="order_review"
                                    class="col-md-6 col-lg-5 col-xl-4 woocommerce-checkout-review-order">
                                    <div id="checkoutAccordion" class="border border-gray-900 bg-white mb-5">
                                        <div class="p-4d875 border">
                                            <div id="checkoutHeadingOnee" class="checkout-head">
                                                <a href="#"
                                                    class="text-dark d-flex align-items-center justify-content-between"
                                                    data-toggle="collapse" data-target="#checkoutCollapseOnee"
                                                    aria-expanded="true" aria-controls="checkoutCollapseOnee">
                                                    <h3 class="checkout-title mb-0 font-weight-medium font-size-3">Your
                                                        order</h3>
                                                    <svg class="mins" xmlns="http://www.w3.org/2000/svg"
                                                        xmlns:xlink="http://www.w3.org/1999/xlink" width="15px"
                                                        height="2px">
                                                        <path fill-rule="evenodd" fill="rgb(22, 22, 25)"
                                                            d="M0.000,-0.000 L15.000,-0.000 L15.000,2.000 L0.000,2.000 L0.000,-0.000 Z" />
                                                    </svg>
                                                    <svg class="plus" xmlns="http://www.w3.org/2000/svg"
                                                        xmlns:xlink="http://www.w3.org/1999/xlink" width="15px"
                                                        height="15px">
                                                        <path fill-rule="evenodd" fill="rgb(22, 22, 25)"
                                                            d="M15.000,8.000 L9.000,8.000 L9.000,15.000 L7.000,15.000 L7.000,8.000 L0.000,8.000 L0.000,6.000 L7.000,6.000 L7.000,-0.000 L9.000,-0.000 L9.000,6.000 L15.000,6.000 L15.000,8.000 Z" />
                                                    </svg>
                                                </a>
                                            </div>
                                            <div id="checkoutCollapseOnee" class="mt-4 checkout-content collapse show"
                                                aria-labelledby="checkoutHeadingOnee"
                                                data-parent="#checkoutAccordion">
                                                <table class="shop_table woocommerce-checkout-review-order-table">
                                                    <thead class="d-none">
                                                        <tr>
                                                            <th class="product-name">Product</th>
                                                            <th class="product-total">Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                            $sub = 0;
                                                        ?>
                                                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr class="cart_item">
                                                                <input type="hidden" name="pid[]"
                                                                    value="<?php echo e($items->product_id); ?>">
                                                                <input type="hidden" name="quantity[]"
                                                                    value="<?php echo e($items->quantity); ?>">
                                                                <input type="hidden" name="price[]"
                                                                    value="<?php echo e($items->price); ?>">
                                                                <input type="hidden" name="cart_id[]"
                                                                    value="<?php echo e($items->cart_id); ?>">
                                                                <td class="product-name">
                                                                    <?php echo e($items->product_name); ?>

                                                                    (<?php echo e($items->language); ?>)
                                                                    &nbsp; <strong class="product-quantity">×
                                                                        <?php echo e($items->quantity); ?></strong>
                                                                </td>
                                                                <td class="product-total">
                                                                    <span class="woocommerce-Price-amount amount"><span
                                                                            class="woocommerce-Price-currencySymbol">₹</span><?php echo e($items->price); ?>.00</span>
                                                                </td>
                                                            </tr>
                                                            <?php
                                                                $sub += $items->price * $items->quantity;
                                                            ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                    <tfoot class="d-none">
                                                        <tr class="cart-subtotal">
                                                            <th>Subtotal</th>
                                                            <td><span class="woocommerce-Price-amount amount"><span
                                                                        class="woocommerce-Price-currencySymbol">₹</span><?php echo e($sub); ?>.00</span>
                                                            </td>
                                                        </tr>
                                                        <input type="hidden" name="total_amount"
                                                            value="<?php echo e($sub); ?>">
                                                        <tr class="order-total">
                                                            <th>Total</th>
                                                            <td><strong><span
                                                                        class="woocommerce-Price-amount amount"><span
                                                                            class="woocommerce-Price-currencySymbol">₹</span><?php echo e($sub); ?>.00</span></strong>
                                                            </td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="p-4d875 border">
                                            <div id="checkoutHeadingOne" class="checkout-head">
                                                <a href="#"
                                                    class="text-dark d-flex align-items-center justify-content-between"
                                                    data-toggle="collapse" data-target="#checkoutCollapseOne"
                                                    aria-expanded="true" aria-controls="checkoutCollapseOne">
                                                    <h3 class="checkout-title mb-0 font-weight-medium font-size-3">Cart
                                                        Totals</h3>
                                                    <svg class="mins" xmlns="http://www.w3.org/2000/svg"
                                                        xmlns:xlink="http://www.w3.org/1999/xlink" width="15px"
                                                        height="2px">
                                                        <path fill-rule="evenodd" fill="rgb(22, 22, 25)"
                                                            d="M0.000,-0.000 L15.000,-0.000 L15.000,2.000 L0.000,2.000 L0.000,-0.000 Z" />
                                                    </svg>
                                                    <svg class="plus" xmlns="http://www.w3.org/2000/svg"
                                                        xmlns:xlink="http://www.w3.org/1999/xlink" width="15px"
                                                        height="15px">
                                                        <path fill-rule="evenodd" fill="rgb(22, 22, 25)"
                                                            d="M15.000,8.000 L9.000,8.000 L9.000,15.000 L7.000,15.000 L7.000,8.000 L0.000,8.000 L0.000,6.000 L7.000,6.000 L7.000,-0.000 L9.000,-0.000 L9.000,6.000 L15.000,6.000 L15.000,8.000 Z" />
                                                    </svg>
                                                </a>
                                            </div>
                                            <div id="checkoutCollapseOne" class="mt-4 checkout-content collapse show"
                                                aria-labelledby="checkoutHeadingOne" data-parent="#checkoutAccordion">
                                                <table class="shop_table shop_table_responsive">
                                                    <tbody>
                                                        <tr class="checkout-subtotal">
                                                            <th>Subtotal</th>
                                                            <td data-title="Subtotal"><span
                                                                    class="woocommerce-Price-amount amount"
                                                                    id="total_amount"><span
                                                                        class="woocommerce-Price-currencySymbol">₹</span><?php echo e($sub); ?>.00</span>
                                                            </td>
                                                        </tr>
                                                        <tr class="order-shipping">
                                                            <th>Shipping</th>
                                                            <td data-title="Shipping">Free Shipping</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        
                                        <div class="p-4d875 border">
                                            <table class="shop_table shop_table_responsive">
                                                <tbody>
                                                    <tr class="order-total">
                                                        <th>Total</th>
                                                        <td data-title="Total"><strong><span
                                                                    class="woocommerce-Price-amount amount"><span
                                                                        class="woocommerce-Price-currencySymbol">₹</span><?php echo e($sub); ?>.00</span></strong>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                                <input type="hidden" name="sub" value="<?php echo e($sub); ?>">
                                            </table>
                                        </div>
                                        <div class="p-4d875 border">
                                            <div id="checkoutHeadingThreee" class="checkout-head">
                                                <a href="#"
                                                    class="text-dark d-flex align-items-center justify-content-between"
                                                    data-toggle="collapse" data-target="#checkoutCollapseThreee"
                                                    aria-expanded="true" aria-controls="checkoutCollapseThreee">
                                                    <h3 class="checkout-title mb-0 font-weight-medium font-size-3">
                                                        Payment</h3>
                                                    <svg class="mins" xmlns="http://www.w3.org/2000/svg"
                                                        xmlns:xlink="http://www.w3.org/1999/xlink" width="15px"
                                                        height="2px">
                                                        <path fill-rule="evenodd" fill="rgb(22, 22, 25)"
                                                            d="M0.000,-0.000 L15.000,-0.000 L15.000,2.000 L0.000,2.000 L0.000,-0.000 Z" />
                                                    </svg>
                                                    <svg class="plus" xmlns="http://www.w3.org/2000/svg"
                                                        xmlns:xlink="http://www.w3.org/1999/xlink" width="15px"
                                                        height="15px">
                                                        <path fill-rule="evenodd" fill="rgb(22, 22, 25)"
                                                            d="M15.000,8.000 L9.000,8.000 L9.000,15.000 L7.000,15.000 L7.000,8.000 L0.000,8.000 L0.000,6.000 L7.000,6.000 L7.000,-0.000 L9.000,-0.000 L9.000,6.000 L15.000,6.000 L15.000,8.000 Z" />
                                                    </svg>
                                                </a>
                                            </div>
                                            <div id="checkoutCollapseThreee"
                                                class="mt-4 checkout-content collapse show"
                                                aria-labelledby="checkoutHeadingThreee"
                                                data-parent="#checkoutAccordion">
                                                <div id="payment" class="woocommerce-checkout-payment">
                                                    <ul class="wc_payment_methods payment_methods methods">
                                                        
                                                        <li class="wc_payment_method payment_method_cod">
                                                            <input id="payment_method_cod" type="radio"
                                                                class="input-radio" name="payment_method"
                                                                value="cod" checked="checked"
                                                                data-order_button_text="">
                                                            <label for="payment_method_cod">Cash on delivery </label>
                                                            <div class="payment_box payment_method_cod"
                                                                style="display: block;">
                                                                <p>Pay with cash upon delivery.</p>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            <input id="payment_method_cod" type="radio"
                                                                class="input-radio" name="payment_method"
                                                                value="razor_pay" data-order_button_text="">
                                                            <label for="payment_method_cod">RazorPay </label>
                                                            <div class="payment_box payment_method_cod"
                                                                style="display: block;">
                                                                <p>Make your payment via RazorPay.</p>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="payment_id" >
                                    <div class="form-row place-order">
                                        <button type="submit"
                                            class="button alt btn btn-dark btn-block rounded-0 py-4">Place
                                            order</button>
                                        
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </article>

            </main>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $('#placeOrder').submit(function(e) {
        e.preventDefault();

        var fname = $('#billing_first_name').val();
        var lname = $('#billing_last_name').val();
        var phone = $('#billing_phone').val();
        var email = $('#billing_email').val();
        var add1 = $('#billing_address_1').val();
        var add2 = $('#billing_address_2').val();
        var city = $('#billing_city').val();
        var postal = $('#billing_postcode').val();
        var amount = parseFloat($('input[name="sub"]').val()).toFixed(2);

        var product = $('input[name="pid[]"]').val();
        var quantity = $('input[name="quantity[]"]').val();
        var price = $('input[name="price[]"]').val();
        var cart_id = $('input[name="cart_id[]"]').val();

        // var fname = $('#billing_first_name').val();
        // var lname = $('#billing_last_name').val();
        // var phone = $('#billing_phone').val();
        // var email = $('#billing_email').val();
        // var add1 = $('#billing_address_1').val();
        // var add2 = $('#billing_address_2').val();
        // var city = $('#billing_city').val();
        // var postal = $('#billing_postcode').val();
        // var amount = $('#total_amount').val();

        // var product = $('input[name="pid[]"]').val();
        // var quantity = $('input[name="quantity[]"]').val();
        // var price = $('input[name="price[]"]').val();
        // var cart_id = $('input[name="cart_id[]"]').val();

        var data = {
            "fname": fname,
            "lname": lname,
            "phone": phone,
            "email": email,
            "add1": add1,
            "add2": add2,
            "city": city,
            "postal": postal,
            "amount": amount,
            "product": product,
            "quantity": quantity,
            "price": price,
            "cart_id": cart_id
        }

        if ($("input[name='payment_method']:checked").val() == "cod") {
            $.ajax({
                url: "<?php echo e(route('PlaceOrder')); ?>",
                type: "POST",
                data: $(this).serialize(),

                success: function(response) {
                    self.location = response.link;
                }
            });
        } else if ($("input[name='payment_method']:checked").val() == "razor_pay") {
            e.preventDefault();
            var options = {
                "key": "<?php echo e(env('RAZOR_KEY')); ?>", // Enter the Key ID generated from the Dashboard
                "amount": amount *
                    100, // Amount is in currency subunits. Default currency is INR. Hence, 10 refers to 1000 paise
                "currency": "INR",
                "name": fname + ' ' + lname,
                "description": "ThankYou For Choosing Us",
                "image": "http://127.0.0.1:8000/images/logo.jpg",
                "order_id": "", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
                "handler": function(response) {
                    $('input[name="payment_id"]').val(response.razorpay_payment_id);
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: 'POST',
                        url: "<?php echo e(route('PlaceOrder')); ?>",
                        data: $("#placeOrder").serialize(),
                        success: function(response) {
                            // Swal.fire({
                            //     title: response.type,
                            //     text: response.success,
                            //     icon: response.type,
                            //     confirmButtonText: 'Done'
                            // }).
                            setTimeout(function() {
                                self.location = response.link;
                            }, 800);
                        }
                    });
                },
                "prefill" : {
                    "name" : fname + ' ' + lname,
                    "email" : email,
                    "contact" : phone,
                },
                "theme" : {
                    "color" : "#3399cc",
                }
            };
            var rzp1 = new Razorpay(options);
            rzp1.on('payment.failed', function(response) {
                alert(response.error.code);
                alert(response.error.description);
                alert(response.error.source);
                alert(response.error.step);
                alert(response.error.reason);
                alert(response.error.metadata.order_id);
                alert(response.error.metadata.payment_id);
            });
            rzp1.open();
        }
    });
</script>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ecomm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\laravel_prg\KanzulImaan\resources\views/pages/ecomm/checkout.blade.php ENDPATH**/ ?>
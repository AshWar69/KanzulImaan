<?php $__env->startSection('ecomm_content'); ?>
    <main id="content">
        <div class="bg-gray-200 space-bottom-3">
            <div class="container">
                <div class="py-5 py-lg-7">
                    <h6 class="font-weight-medium font-size-7 text-center mt-lg-1">Order Received</h6>
                </div>
                <div class="max-width-890 mx-auto">
                    <div class="bg-white pt-6 border">
                        <h6 class="font-size-3 font-weight-medium text-center mb-4 pb-xl-1">Thank you. Your order has been
                            received.</h6>
                        <div class="border-bottom mb-5 pb-5 overflow-auto overflow-md-visible">
                            <div class="pl-3">
                                <table class="table table-borderless mb-0 ml-1">
                                    <thead>
                                        <tr>
                                            <th scope="col" class="font-size-2 font-weight-normal py-0">Order number:
                                            </th>
                                            <th scope="col" class="font-size-2 font-weight-normal py-0">Date:</th>
                                            <th scope="col" class="font-size-2 font-weight-normal py-0 text-md-center">
                                                Total: </th>
                                            <th scope="col"
                                                class="font-size-2 font-weight-normal py-0 text-md-right pr-md-9">Payment
                                                method:</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row" class="pr-0 py-0 font-weight-medium"><?php echo e($orders->order_no); ?>

                                            </th>
                                            <td class="pr-0 py-0 font-weight-medium">
                                                <?php echo e(date('F j, Y', strtotime($orders->order_date))); ?></td>
                                            <td class="pr-0 py-0 font-weight-medium text-md-center">₹<?php echo e($orders->total); ?>/-
                                            </td>
                                            <td class="pr-md-4 py-0 font-weight-medium text-md-center text-uppercase">
                                                <?php echo e($orders->payment_mode); ?>

                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="border-bottom mb-5 pb-6">
                            <div class="px-3 px-md-4">
                                <div class="ml-md-2">
                                    <h6 class="font-size-3 on-weight-medium mb-4 pb-1">Order Details</h6>
                                    <?php $sub=0; ?>
                                    <?php $__currentLoopData = $orders->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex justify-content-between mb-4">
                                            <div class="d-flex align-items-baseline">
                                                <div>
                                                    <h6 class="font-size-2 font-weight-normal mb-1">
                                                        <?php echo e($order->products->product_name); ?></h6>
                                                    <span class="font-size-2 text-gray-600">(<?php echo e($order->products->format); ?>,
                                                        <?php echo e($order->products->language); ?>)</span>
                                                </div>
                                                <span
                                                    class="font-size-2 ml-4 ml-md-8">x<?php echo e($order->products->quantity); ?></span>
                                            </div>
                                            <span class="font-weight-medium font-size-2">₹
                                                <?php echo e($order->products->price); ?></span>
                                        </div>
                                        <?php $sub += $order->quantity*$order->price; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="border-bottom mb-5 pb-5">
                            <ul class="list-unstyled px-3 pl-md-5 pr-md-4 mb-0">
                                <li class="d-flex justify-content-between py-2">
                                    <span class="font-weight-medium font-size-2">Subtotal:</span>
                                    <span class="font-weight-medium font-size-2">₹<?php echo e($sub); ?></span>
                                </li>
                                <li class="d-flex justify-content-between py-2">
                                    <span class="font-weight-medium font-size-2">Shipping:</span>
                                    <span class="font-weight-medium font-size-2">Free Shipping</span>
                                </li>
                                <li class="d-flex justify-content-between pt-2">
                                    <span class="font-weight-medium font-size-2">Payment Method:</span>
                                    <span
                                        class="font-weight-medium font-size-2 text-uppercase"><?php echo e($orders->payment_mode); ?></span>
                                </li>
                            </ul>
                        </div>
                        <div class="border-bottom mb-5 pb-4">
                            <div class="px-3 pl-md-5 pr-md-4">
                                <div class="d-flex justify-content-between">
                                    <span class="font-size-2 font-weight-medium">Total</span>
                                    <span class="font-weight-medium fon-size-2"><?php echo e($orders->total); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="px-3 pl-md-5 pr-md-4 mb-6 pb-xl-1">
                            <div class="row row-cols-1 row-cols-md-2">
                                <div class="col">
                                    <div class="mb-6 mb-md-0">
                                        <h6 class="font-weight-medium font-size-22 mb-3">Billing Address
                                        </h6>
                                        <address class="d-flex flex-column mb-0">
                                            <span class="text-gray-600 font-size-2"><?php echo e($user_details->first_name); ?>

                                                <?php echo e($user_details->last_name); ?></span>
                                            <span class="text-gray-600 font-size-2"><?php echo e($user_details->add1); ?>,</span>
                                            <?php if($user_details->add2 > ''): ?>
                                                <span class="text-gray-600 font-size-2"><?php echo e($user_details->add2); ?>,</span>
                                            <?php endif; ?>
                                            <span class="text-gray-600 font-size-2"><?php echo e($user_details->city); ?>

                                                <?php echo e($user_details->postal); ?></span>
                                            <span class="text-gray-600 font-size-2">India</span>
                                        </address>
                                    </div>
                                </div>
                                <div class="col">
                                    <h6 class="font-weight-medium font-size-22 mb-3">Shipping Address
                                    </h6>
                                    <address class="d-flex flex-column mb-0">
                                        <span class="text-gray-600 font-size-2"><?php echo e($user_details->first_name); ?>

                                            <?php echo e($user_details->last_name); ?></span>
                                        <span class="text-gray-600 font-size-2"><?php echo e($user_details->add1); ?>,</span>
                                        <?php if($user_details->add2 > ''): ?>
                                            <span class="text-gray-600 font-size-2"><?php echo e($user_details->add2); ?>,</span>
                                        <?php endif; ?>
                                        <span class="text-gray-600 font-size-2"><?php echo e($user_details->city); ?>

                                            <?php echo e($user_details->postal); ?></span>
                                        <span class="text-gray-600 font-size-2">India</span>
                                    </address>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ;
    <script>
        $(document).ready(function() {
            setTimeout(function() {
                self.location = "<?php echo e(URL::to('QuranStore')); ?>";
            }, 4000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ecomm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\laravel_prg\KanzulImaan\resources\views/pages/ecomm/order_received.blade.php ENDPATH**/ ?>
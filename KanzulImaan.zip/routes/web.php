<?php

use App\Http\Controllers\EcommController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('pages.index');
});



Route::get('Dashboard', function () {
    return view('backend.pages.admin');
});

Route::get('AddProduct', function () {
    return view('backend.pages.ecommerce.addProduct');
});
Route::post('saveProduct',[EcommController::class, 'storeProduct'])->name('saveProduct');
Route::get('product/destroy/{id}', [EcommController::class, 'destroyProduct']);
Route::get('ProductsShowcase', [EcommController::class, 'showProducts']);
Route::get('ShowOrders', [EcommController::class, 'viewOrder']);
Route::get('viewDetail/order_no={id}', [EcommController::class, 'OrderDetails']);

Auth::routes();
Route::middleware(['auth','ecomm'])->group(function(){
    Route::get('QuranStore', [EcommController::class, 'showQuranStore']);
    Route::get('Product/id={id}', [EcommController::class, 'showSingleProduct']);
    Route::get('removeItem/{id}', [EcommController::class, 'removeCartItems']);
    Route::get('ViewCart', [EcommController::class, 'viewCart']);
    Route::post('addtocart', [EcommController::class, 'AddToCart'])->name('addtocart');
    Route::post('AddCart', [EcommController::class, 'DirectAddcart'])->name('AddCart');
    Route::post('changeQuantity', [EcommController::class, 'changeQuantity'])->name('changeQuantity');
    Route::get('Checkout', [EcommController::class, 'viewCheckout']);
    Route::post('PlaceOrder', [EcommController::class, 'placeOrder'])->name('PlaceOrder');
    Route::get('OrderReceived/order_no={id}', [EcommController::class, 'orderReceived']);
});

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
